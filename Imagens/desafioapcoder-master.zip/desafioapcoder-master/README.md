<h1>                     Desafio ApCoders</h1>


![Captura de tela 2022-01-18 021313](https://user-images.githubusercontent.com/94265037/149877559-8455776f-5717-4a63-aa48-324b9867f739.png)

<h4>Linguagem utilizada : DELPHI 10 SEATTLE 
<br>Banco de dados      : Firebird 3.0 
<br>Ferramentas         : Power Designer (Modelagem do Banco de dados)  e   Tescomplete 5(Rotinas de testes)</h4>




<h2>Implementação da solução</h3>
 Para a criação do projeto eu utilizei o trello para gerenciar as tarefas,
 iniciando com levantamento de requisitos e planejando a modelagem do  banco de dados no software Power Designer 
 a padronização do projeto foi no modelo MVC
<Strong> <br><br>link do trello</Strong>: https://trello.com/b/yRAVDZiY/desafio-apcoders
 
 ![cap](https://user-images.githubusercontent.com/94265037/149877324-28b2d573-d9c6-4cbb-970f-5a83f38a1f3c.png)


<h2>Modelagem do banco de dados</h2>

![DiagramaKondominios](https://user-images.githubusercontent.com/94265037/150081132-9679ce1a-5e52-4243-8f52-d5f49e7a09ee.png)

<h2>Rodando a aplicação</h2>
Após baixar o diretório e descompactar no seu computador<br>
Instalar o banco de dados por meio do instalador INSTALADORFIREBIRD.exe <br>

![image](https://user-images.githubusercontent.com/94265037/149885128-e3eb3424-66a5-4000-a184-5e12578c4931.png)

![com rodar](https://user-images.githubusercontent.com/94265037/150700123-8ddc36ab-afc1-47b1-8023-a78a14ffbc8a.png)

<br>Senha: masterkey <br>

![como rodar](https://user-images.githubusercontent.com/94265037/150699975-26e836ea-095e-4482-b6b3-98781f9585bd.png)<br>

após isso, entrar na pasta \Projeto\Win32\Debug e executar o arquivo Syndico.exe<br>


![image](https://user-images.githubusercontent.com/94265037/149885485-de2302c7-e11a-4f0a-ba84-070b86d938be.png)
<h2>Gif da instalação e execução da aplicação<h2>

![Desktop 2022 01 18 - 03 25 22 04_Trim](https://user-images.githubusercontent.com/94265037/149884736-eb9806f8-8e51-45f9-9986-ae77139a8afe.gif)

